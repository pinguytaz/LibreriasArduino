g++ base.cpp -o base `pkg-config --cflags --libs opencv4`
